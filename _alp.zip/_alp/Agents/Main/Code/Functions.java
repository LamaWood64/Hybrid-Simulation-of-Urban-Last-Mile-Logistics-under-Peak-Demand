void setupNormalDay()
{/*ALCODESTART::1770281541713*/
total_delivered = 0;
order_source_hub1.set_rate(0.1);
order_source_hub2.set_rate(0.1); 

traceln("NORMAL DAY: rate 0.1 + 0.1 = 0.2 orders/min");
/*ALCODEEND*/}

void setupPeakDay()
{/*ALCODESTART::1770281807915*/
total_delivered = 0;
order_source_hub1.set_rate(0.2);  
order_source_hub2.set_rate(0.2);  

traceln("PEAK DAY: rate 0.2 + 0.2 = 0.4 orders/min");
/*ALCODEEND*/}

void showStatistics()
{/*ALCODESTART::1770281870905*/
// ВЕРСИЯ БЕЗ ОШИБОК КОМПИЛЯЦИИ
traceln("\n==========================================");
traceln("CURRENT SIMULATION STATISTICS");
traceln("==========================================");

// 1. ТОЛЬКО ТО, ЧТО ТОЧНО РАБОТАЕТ
traceln("Simulation time: " + time() + " minutes");
traceln("Total delivered: " + total_delivered);
traceln("Queue HUB1: " + hub_queue1.size() + " orders");
traceln("Queue HUB2: " + hub_queue2.size() + " orders");

// 2. Просто показываем размер данных без сложной логики
if (delivery_data != null) {
    try {
        // Безопасная проверка типа
        if (delivery_data.getClass().getName().contains("List")) {
            java.util.List list = (java.util.List) delivery_data;
            traceln("Delivery time samples: " + list.size());
        } else {
            traceln("Delivery data type: " + delivery_data.getClass().getSimpleName());
        }
    } catch (Exception e) {
        traceln("Delivery data: Available (type unknown)");
    }
}

// 3. Простая проверка курьеров (без методов)
traceln("\nCourier status (assumed):");
traceln("HUB1: 5 couriers total");
traceln("HUB2: 5 couriers total");

// 4. Сценарий
if (currentScenario != null) {
    traceln("Active scenario: " + currentScenario);
}

traceln("==========================================");
/*ALCODEEND*/}

