void end_simulation_event()
{/*ALCODESTART::1770203883759*/
traceln("Total simulation time: 1440 minutes (24 hours)");
traceln("Total orders delivered: " + total_delivered);
traceln("Final backlog: " + (hub_queue1.size() + hub_queue2.size()));

getEngine().stop();
/*ALCODEEND*/}

void peakDayStatsEvent()
{/*ALCODESTART::1770283942678*/
traceln("\n" + "=".repeat(50));
traceln("PEAK DAY RESULTS AFTER 480 MINUTES:");
showStatistics();
traceln("=".repeat(50));
/*ALCODEEND*/}

void normalDayStatsEvent()
{/*ALCODESTART::1770284041103*/
traceln("\n" + "=".repeat(50));
traceln("Normal DAY RESULTS AFTER 480 MINUTES:");
showStatistics();
traceln("=".repeat(50));
/*ALCODEEND*/}

void update_chart_event()
{/*ALCODESTART::1770413081898*/
// В Event оставьте ТОЛЬКО ЭТО:
chart.updateData();
/*ALCODEEND*/}

