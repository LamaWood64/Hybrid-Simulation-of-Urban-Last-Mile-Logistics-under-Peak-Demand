public int customer_id;
public int hub_id;
public double creation_time;
public double delivery_start_time;
public double delivery_duration;  
public double total_time;        
public int assigned_courier_id;